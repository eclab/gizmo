#include "All.h"

/// Send a K4 SysEx command corresponding to a given parameter number and its value.
/// If DRAW is 1, then we also draw on-screen the parameter number (at left) and the
/// SOURCE, DRUM, or EFFECT setting (at right).  The actual value is not drawn!
void sendKawaiK4Sysex(uint8_t number, uint8_t value, uint8_t draw)
	{
	uint8_t sysExArray[KAWAI_K4_SYSEXLEN] = { 0x40, options.channelOut, 0x10, 0x0, 0x04, number, 0, 0 };

	if (number <= 69)
		sysExArray[6] = local.kawai.source << 1 | value >> 7;
	else if (number <= 81)
		sysExArray[6] = local.kawai.drum << 1 | value >> 7;
	else 
		sysExArray[6] = local.kawai.effect << 1 | value >> 7;
		
	sysExArray[7] = (uint8_t)(value & 0x127);
	
	MIDI.sendSysEx(KAWAI_K4_SYSEXLEN, sysExArray, false);
	
	if (draw)
		{
		writeShortNumber(led2, number, true);
		writeShortNumber(led, (number <= 69 ? local.kawai.source :
							number <= 88 ? local.kawai.drum : local.kawai.effect), false);
		}
	}

/// State function for STATE_UTILITY_KAWAI_K4
void stateUtilityKawaiK4()

			{
		if (isUpdated(BACK_BUTTON, RELEASED) || isUpdated(SELECT_BUTTON, PRESSED))
			{
			suggestedDefaultState = state; 
			state = STATE_ROOT;					// Or whatever I'm under
			entry = true;
			}

			if (newItem && itemType == MIDI_NRPN_14_BIT)
				{
				clearScreen();
				
				if (itemNumber <= 88)  // highest Kawai message
					{
					sendKawaiK4Sysex((uint8_t)itemNumber, (uint8_t)itemValue, true);
					}
				else if (itemNumber >= KAWAI_K4_PARAMETER_S1_MUTE && itemNumber <= KAWAI_K4_PARAMETER_VIBRATO_SHAPE)
					{
					switch(itemNumber)
						{
						case KAWAI_K4_PARAMETER_S1_MUTE:  // handled specially
							local.kawai.p17 = (local.kawai.p17 & 254) | (itemValue & 1);
							break;
						case KAWAI_K4_PARAMETER_S2_MUTE:  // handled specially
							local.kawai.p17 = (local.kawai.p17 & 253) | ((itemValue & 2) << 1);					
							break;
						case KAWAI_K4_PARAMETER_S3_MUTE:  // handled specially
							local.kawai.p17 = (local.kawai.p17 & 250) | ((itemValue & 4) << 2);
							break;
						case KAWAI_K4_PARAMETER_S4_MUTE:  // handled specially
							local.kawai.p17 = (local.kawai.p17 & 247) | ((itemValue & 8) << 3);
							break;
						case KAWAI_K4_PARAMETER_VIBRATO_SHAPE:  // handled specially
							local.kawai.p17 = (local.kawai.p17 & 207) | ((itemValue & 48) << 4);
							break;
						}
						
					sendKawaiK4Sysex(17, local.kawai.p17, false);
					
					if (itemNumber == KAWAI_K4_PARAMETER_VIBRATO_SHAPE)
						{
						write3x5Glyph(led2, GLYPH_3x5_V, 0);  // write the V for vibrato
						write3x5Glyph(led2, GLYPH_3x5_S, 4);  // write the S for shape
						writeShortNumber(led, itemValue, false);
						}
					else
						{
						writeShortNumber(led2, (itemNumber - KAWAI_K4_PARAMETER_S1_MUTE + 1), true);   // writes 1 for S1 etc.
						write3x5Glyph(led2, GLYPH_3x5_M, 0);  // write an the M for MUTE etc.
						writeShortNumber(led, itemValue, false);
						}
					}
				else if (itemNumber == KAWAI_K4_SOURCE_PARAMETER)
					{
					if (itemValue > 3) itemValue = 0;
					local.kawai.source = ((uint8_t) itemValue);
					// update display regardless.  Does this work?
					writeShortNumber(led, itemValue, false);
					write3x5Glyph(led2, GLYPH_3x5_S, 0);  // write an S for SOURCE
					}
				else if (itemNumber == KAWAI_K4_DRUM_PARAMETER)
					{
					if (itemValue > 60) itemValue = 0;
					local.kawai.drum = ((uint8_t) itemValue);
					// update display regardless.  Does this work?
					writeShortNumber(led, itemValue, false);
					write3x5Glyph(led2, GLYPH_3x5_P, 0);  // write an P for PARAMETER
					}
				else if (itemNumber == KAWAI_K4_EFFECT_PARAMETER)
					{
					if (itemValue > 7) itemValue = 0;
					local.kawai.effect = ((uint8_t) itemValue);
					// update display regardless.  Does this work?
					writeShortNumber(led, itemValue, false);
					write3x5Glyph(led2, GLYPH_3x5_E, 0);  // write an E for EFFECT
					}
				}
			}